Glossary
========

VM
---

A Virtual Machine (Dynamips, IOU, Qemu, VPCS...)

Adapter
-------

The physical network interface. The adapter can contain multiple ports.

Port
----

A port is an opening on network adapter that cable plug into.

For example a VM can have a serial and an ethernet adapter plugged in.
The ethernet adapter can have 4 ports.
