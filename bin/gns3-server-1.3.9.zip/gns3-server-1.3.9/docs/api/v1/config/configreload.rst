/v1/config/reload
----------------------------------------------------------------------------------------------------------------------

.. contents::

POST /v1/config/reload
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Check if version is the same as the server

Response status codes
**********************
- **201**: Config reload
- **403**: Config reload refused

Sample session
***************


.. literalinclude:: ../../examples/post_configreload.txt

