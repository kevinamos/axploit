Welcome to API documentation!
======================================

.. WARNING::
   The API is not stable, feel free to send comment on GNS3 Jungle
   https://community.gns3.com/

.. toctree::
    general
    glossary
    development


API Endpoints
~~~~~~~~~~~~~~~

.. toctree::
   :glob:
   :maxdepth: 2
   
   api/v1/*

